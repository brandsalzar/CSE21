package pig;

public class RiskyPlayer extends Player {


	
	
}
